//Bismillah

//kode setelah // (garing 2*) tidak akan berfungsi

package id.contoh.kibot;

import android.inputmethodservice.*;
import android.view.*;
import android.view.inputmethod.*;

public class KibotIME extends InputMethodService implements KeyboardView.OnKeyboardActionListener
{

	//Deklarasi/pengenalan (iki sendal)
	private KeyboardView kv;
	private Keyboard keQwerty;
	private Keyboard keSymbols;
	private boolean capsCuss;










	public View onCreateInputView()
	{//tulis skrip didlm kurung {} ini untuk deklarasi keyboard

		kv = (KeyboardView)getLayoutInflater().inflate(R.layout.input, null);
		keQwerty = new Keyboard(this, R.xml.qwerty);
		keSymbols = new Keyboard(this, R.xml.symbols);
		kv.setKeyboard(keQwerty);
		kv.setOnKeyboardActionListener(this);
		kv.invalidateAllKeys();
		return kv;
	}// public View onCreateInputView()










	@Override
	public void onKey(int tombolKibot, int[] p2)
	{// masukkn fungsi dari tombol kibot {} 

		InputConnection ic = getCurrentInputConnection();
		// deklarasi ic sbg InputConnection trus getCurrentInputConnection();

		switch (tombolKibot)
		{
			case Keyboard.KEYCODE_DELETE : //-5 pada qwerty.xml
				ic.deleteSurroundingText(1, 0);
				break;
				//ic telah diDeklarasi diatas sbg InputConnection
				//jika belum dideklrasi. **ic.deleteSurroundingText(1, 0);** kode akan eror.

				//kode **ic.deleteSurroundingText(1, 0);** juga bisa diganti dg kode
				//getCurrentInputConnection().deleteSurroundingText(1, 0);
				//tapi kan agak panjang, ya kan???
				// selain itu ***ic*** juga masih digunakan dibawah nanti
			case Keyboard.KEYCODE_SHIFT: //-1 pada qwerty.xml
				capsCuss = !capsCuss; //metode buat on off
				keQwerty.setShifted(capsCuss); //membuat kibot jadi huruf besar/kecil sesuai **capsCuss**
				kv.invalidateAllKeys(); //merefresh keyboard
				break;
			case Keyboard.KEYCODE_DONE: //-4 pada qwerty.xml
				ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER));
				break;
				//kode ini mengirimkan keyEvent ENTER
				//jika kode dirubah jd gini
				//ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_UP))
				//mka akn berubah jadi Dpad UP atau Arah Atas
			case -201: //baca ke 01 atau keQwerty
				keQwerty = new Keyboard(this, R.xml.qwerty);
				//keSymbols = new Keyboard(this, R.xml.qwerty);
				kv.setKeyboard(keQwerty);
				kv.invalidateAllKeys();
				break;
			case -202: //baca ke 02 atau keSymbols
				//keQwerty = new Keyboard(this, R.xml.qwerty);
				keSymbols = new Keyboard(this, R.xml.symbols);
				kv.setKeyboard(keSymbols);
				kv.invalidateAllKeys();
				break;
			case -203: //baca ke 02 atau keSymbols
				keQwerty = new Keyboard(this, R.xml.qwerty);
				//keSymbols = new Keyboard(this, R.xml.symbols);
				kv.setKeyboard(keQwerty);
				kv.invalidateAllKeys();
				break;
			case -252:
				ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_UP));
				break;
			case -254:
				ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_LEFT));
				break;
			case -256:
				ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_RIGHT));
				break;
			case -258:
				ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_DOWN));
				break;
			case -777:
				ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_TAB));
				break;
			default:
				//kode dibawah ini berfungsi agar huruf A-Z bisa untuk mengetik
				char code = (char)tombolKibot;
				if (Character.isLetter(code) && kv.isShifted())
				{
					code = Character.toUpperCase(code);
				}
				ic.commitText(String.valueOf(code), 1);					
		}

	}// public void onKey(int tombolKibot, int[] p2)









	@Override
	public void onPress(int p1)
	{
		// TODO: Implement this method
	}

	@Override
	public void onRelease(int p1)
	{
		// TODO: Implement this method
	}

	@Override
	public void onText(CharSequence p1)
	{
		// TODO: Implement this method
	}

	@Override
	public void swipeLeft()
	{
		// TODO: Implement this method
	}

	@Override
	public void swipeRight()
	{
		// TODO: Implement this method
	}

	@Override
	public void swipeDown()
	{
		// TODO: Implement this method
	}

	@Override
	public void swipeUp()
	{
		// TODO: Implement this method
	}

}
